# /// script
# requires-python = ">=3.11"
# dependencies = ["pexpect==4.9.0", "pyte==0.8.2"]
# ///
"""Actual-key, code-aware developer evidence; not independent acceptance."""
import argparse
from datetime import datetime, timezone, timedelta
from decimal import Decimal
import hashlib
import gzip
import http.server
import json
import os
from pathlib import Path
import runpy
import sqlite3
import subprocess
import threading
import time
import uuid

import pexpect
import pyte

parser = argparse.ArgumentParser()
parser.add_argument("binary", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--mode", choices=["collect", "inspect", "limits", "cap", "recovery"], required=True)
parser.add_argument("--fixture", type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
out = args.output.resolve()
repo = Path(__file__).resolve().parents[5]
fixture = (args.fixture or out / "fixture").resolve()
fixture.mkdir(exist_ok=True)
profile = fixture / "profile"
work = fixture / "work"
profile.mkdir(exist_ok=True)
work.mkdir(exist_ok=True)
subprocess.run(["git", "init", "-q", str(work)], check=True)
isolation = runpy.run_path(str(repo / "scripts/isolated_rust_tests.py"))
binary = args.binary.resolve()
receipts = []
keys = []
lock = threading.Lock()
phase = "root"
counts = {}
clock_offset = int(datetime(2026, 8, 10, 12, 15, tzinfo=timezone.utc).timestamp() - time.time())
RATE = {"gpt-5.6-sol": ("5", ".5", "30"), "gpt-5.6-terra": ("2.5", ".25", "15")}
USAGE = {"root": (100, 20, 10, 4), "child": (80, 10, 6, 2), "orphan": (40, 5, 4, 1), "cap": (10, 0, 1, 0)}
def tool_named(body, suffix):
    for item in body.get("tools", []):
        if item.get("name", "").endswith(suffix):
            return None, item["name"]
        for nested in item.get("tools", []):
            if nested.get("name", "").endswith(suffix):
                return item.get("name"), nested["name"]
    raise RuntimeError("Required native tool not exposed: " + suffix)

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass
    def do_GET(self):
        self.send_error(404)
    def do_POST(self):
        global phase
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        with lock:
            kind = "child" if self.headers.get("x-codex-parent-thread-id") else phase
            index = counts.get(kind, 0)
            counts[kind] = index + 1
            inp, cached, output, reasoning = USAGE[kind]
            inp += index
            row = dict(kind=kind, index=index, model=body.get("model"), path=self.path,
                       service_tier=body.get("service_tier"), input=inp, cached=cached,
                       output=output, reasoning=reasoning,
                       real_utc=datetime.now(timezone.utc).isoformat(),
                       fixture_utc=sample_utc)
            receipts.append(row)
            if kind != "cap" or (index + 1) % 50 == 0:
                print(f"Sampled {kind} response {index + 1}", flush=True)
        rid = f"qualify-{kind}-{index}"
        events = [{"type": "response.created", "response": {"id": rid}}]
        if kind == "cap" and index < 512:
            namespace, name = tool_named(body, "list_agents")
            item = dict(type="function_call", call_id=f"fixture-list-{index}", name=name, arguments="{}")
            if namespace:
                item["namespace"] = namespace
            events.append({"type": "response.output_item.done", "item": item})
        elif kind == "root" and index == 0:
            namespace, name = tool_named(body, "spawn_agent")
            item = dict(type="function_call", call_id="fixture-spawn", name=name,
                        arguments=json.dumps(dict(task_name="qualify_child", message="Return child fixture completion.",
                                                  model_provider="openai", model="gpt-5.6-sol",
                                                  reasoning_effort="low", fork_turns="none")))
            if namespace:
                item["namespace"] = namespace
            events.append({"type": "response.output_item.done", "item": item})
        else:
            events.append({"type": "response.output_item.done", "item": {
                "type": "message", "role": "assistant", "id": rid+"-message",
                "content": [{"type": "output_text", "text": f"QUALIFY {kind} complete."}]}})
        events.append({"type": "response.completed", "response": {"id": rid, "usage": {
            "input_tokens": inp, "input_tokens_details": {"cached_tokens": cached, "cache_write_tokens": 0},
            "output_tokens": output, "output_tokens_details": {"reasoning_tokens": reasoning},
            "total_tokens": inp+output}}})
        data = "".join(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n" for e in events).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
catalog = json.loads((repo / "codex-rs/models-manager/models.json").read_text())
for model in catalog["models"]:
    model["tool_mode"] = None
    model["use_responses_lite"] = False
    model["multi_agent_version"] = "v2"
(fixture / "catalog.json").write_text(json.dumps(catalog))
config = (
    'model_provider = "openai"\nmodel = "gpt-5.6-sol"\n'
    'model_reasoning_effort = "low"\ncli_auth_credentials_store = "file"\n'
    'check_for_update_on_startup = false\napproval_policy = "never"\n'
    f'model_catalog_json = {json.dumps(str(fixture / "catalog.json"))}\n'
    f'openai_base_url = "http://127.0.0.1:{server.server_port}/v1"\n'
    '[features]\nsqlite = true\nmulti_agent = true\nmulti_agent_v2 = true\n'
    'code_mode_only = false\ncode_mode_host = false\n'
    f'[projects.{json.dumps(str(work))}]\ntrust_level = "trusted"\n'
)
(profile / "config.toml").write_text(config)
(profile / "auth.json").write_text(json.dumps({"OPENAI_API_KEY": "synthetic-loopback-only"}))
env = isolation["test_environment"]({"PATH": os.environ["PATH"], "HOME": str(fixture)}, profile)
env.update(OPENAI_API_KEY="synthetic-loopback-only", TERM="xterm-256color",
           RUST_LOG="trace", NO_COLOR="1")
if args.mode == "collect":
    env.update(DYLD_INSERT_LIBRARIES=str(Path(__file__).with_name("fixture_clock.dylib")),
               ACCT_QUALIFY_CLOCK_OFFSET_SECONDS=str(clock_offset))
# Network enforcement is a developer fixture control, not agent isolation.
sandbox = fixture / "loopback.sb"
sandbox.write_text('(version 1)\n(allow default)\n(deny network*)\n'
                   '(allow network-outbound (remote ip "localhost:*"))\n'
                   '(allow network-inbound (local ip "localhost:*"))\n')
child = None
screen = None
stream = None
raw = None
def visible():
    return "\n".join(line.rstrip() for line in screen.display)
def drain(seconds=.035):
    until = time.monotonic() + seconds
    while time.monotonic() < until:
        try:
            chunk = child.read_nonblocking(65536, timeout=.01)
        except pexpect.TIMEOUT:
            continue
        except pexpect.EOF:
            break
        stream.feed(chunk)
        if "\x1b[6n" in chunk:
            child.send("\x1b[1;1R")
        if "\x1b[c" in chunk:
            child.send("\x1b[?1;2c")
def send(value):
    keys.append(dict(at=time.time(), value=repr(value)))
    child.send(value)
    drain()
def snap(name):
    text = visible()
    (out / (name+".txt")).write_text(text+"\n")
    return text
def wait_for(predicate, name, timeout=90):
    until = time.monotonic()+timeout
    while time.monotonic() < until:
        drain(.3)
        if predicate():
            return
    snap(name+"-timeout")
    raise RuntimeError("Timed out: "+name)
def launch(name, resume=None):
    global child, screen, stream, raw
    screen = pyte.Screen(180, 60)
    stream = pyte.Stream(screen)
    raw = (out / (name+".raw")).open("w")
    cmd = [str(binary), "--no-alt-screen", "-C", str(work), "-c", f'log_dir="{fixture / "logs"}"']
    if resume:
        cmd += ["resume", resume, "--model", active_model]
    # Launching through sandbox-exec strips DYLD variables, so use env inside it.
    prefix = ["/usr/bin/sandbox-exec", "-f", str(sandbox), "/usr/bin/env"]
    if args.mode == "collect":
        prefix += [f"DYLD_INSERT_LIBRARIES={env['DYLD_INSERT_LIBRARIES']}",
                   f"ACCT_QUALIFY_CLOCK_MS={epoch(sample_utc)}"]
    child = pexpect.spawn(prefix[0], prefix[1:]+cmd, cwd=work, env=env,
                          dimensions=(60, 180), encoding="utf-8", timeout=1)
    child.logfile_read = raw
    wait_for(lambda: active_model in visible(), name+"-startup")
    snap(name+"-startup")
def stop():
    if child is not None and child.isalive():
        for _ in range(2):
            if not child.isalive():
                break
            try:
                send("\x03")
            except OSError:
                break
        drain(.5)
        if child.isalive():
            child.terminate(force=True)
    if raw:
        raw.close()
def database():
    return next(profile.glob("*state_*.sqlite"))
def query(sql, params=()):
    with sqlite3.connect(database()) as db:
        return db.execute(sql, params).fetchall()
def page(name):
    # Home and End are actual keys. Preserve each unique viewport while walking.
    send("\x1b[H")
    views = []
    selected = []
    for _ in range(180):
        text = visible()
        if text not in views:
            views.append(text)
        selections = [line.strip()[1:].strip() for line in text.splitlines()
                      if line.lstrip().startswith("›")]
        current = selections[-1] if selections else ""
        selected.append(current)
        if current == "Close":
            break
        send("\x1b[B")
    else:
        raise RuntimeError("Page traversal never reached Close: "+name)
    (out / (name+".txt")).write_text("\n\n--- NEXT VIEWPORT ---\n\n".join(views)+"\n")
    (out / (name+"-selected.json")).write_text(json.dumps(selected, indent=2)+"\n")
    print("Captured "+name, flush=True)
    return "\n".join(views)
def open_link(label):
    send("\x1b[H")
    for _ in range(180):
        selections = [line.strip()[1:].strip() for line in visible().splitlines()
                      if line.lstrip().startswith("›")]
        current = selections[-1] if selections else ""
        if current == label or (label.endswith("*") and current.startswith(label[:-1])):
            send("\r")
            drain(.3)
            return
        send("\x1b[B")
    raise RuntimeError("Link not found: "+label)
def command(value):
    send(value)
    send("\r")
    wait_for(lambda: ("↑↓ scroll" in visible() and "Loading" not in visible()), "inspector")
def require(text, expected, label):
    if expected not in text:
        raise RuntimeError(f"DEFECT or missing rendered evidence {label}: expected {expected!r}")