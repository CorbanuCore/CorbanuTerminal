# /// script
# requires-python = ">=3.11"
# dependencies = ["pexpect==4.9.0", "pyte==0.8.2"]
# ///
"""Supporting code-aware PTY evidence. Reuses the frozen acct-qualify-50 driver helpers.
Run: uv run --script qualify.py BINARY OUTPUT --mode collect
The profile and exact-clock assets are local synthetic fixtures, not release assets.
"""
from pathlib import Path
import hashlib

prior_path = Path(__file__).resolve().parent.parent / "acct-qualify-50/qualify.py"
prior = prior_path.read_text().split("\ntry:\n    driver_bytes", 1)[0]
# Reuse initialization/navigation, not its old qualification or expectations.
prior = prior.replace('kind = "child" if body.get("model") == "gpt-5.6-terra" else phase',
    'kind = "child" if self.headers.get("x-codex-parent-thread-id") else phase')
prior = prior.replace('inp, cached, output, reasoning = USAGE[kind]',
    'inp, cached, output, reasoning = USAGE[kind]\n            inp += index')
prior = prior.replace('fixture_utc=datetime.fromtimestamp(time.time()+clock_offset, timezone.utc).isoformat()',
    'fixture_utc=sample_utc')
prior = prior.replace('model="gpt-5.6-terra",', 'model="gpt-5.6-sol",')
prior = prior.replace('f"ACCT_QUALIFY_CLOCK_OFFSET_SECONDS={clock_offset}"',
    'f"ACCT_QUALIFY_CLOCK_MS={epoch(sample_utc)}"')
prior = prior.replace('lambda: "gpt-5.6-sol" in visible()', 'lambda: active_model.lower() in visible().lower()')
prior = prior.replace('cmd += ["resume", resume]', 'cmd += ["resume", resume, "--model", active_model]')
prior = prior.replace('def drain(seconds=.12):', 'def drain(seconds=.035):')
prior = prior.replace('timeout=.04', 'timeout=.01')
exec(compile(prior, str(prior_path), "exec"))
sample_utc = "2026-08-30T23:00:00Z"
active_model = "gpt-5.6-sol"
USAGE["checkpoint"] = USAGE["root"]
summary = {"buckets": [], "groups": [], "unknown_causes": [], "partial": []}
expected = []
all_attempt_ids = set()
def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2)+"\n")
def epoch(value):
    return int(datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()*1000)
def set_clock(value):
    global sample_utc
    sample_utc = value
    (fixture / "clock-ms").write_text(str(epoch(value)))
def select_model(model):
    global active_model
    active_model = model
    text = (profile / "config.toml").read_text()
    import re
    text = re.sub(r'^model = "[^"]+"', 'model = "'+model+'"', text, flags=re.MULTILINE)
    (profile / "config.toml").write_text(text)
def sample(name, when, model, resume=None):
    set_clock(when)
    select_model(model)
    before = len(receipts)
    launch(name, resume)
    child.delaybeforesend = 0
    send("Use the fixture response.")
    send("\r")
    if name == "first":
        wait_for(lambda: counts.get("root",0) >= 2 and counts.get("child",0) == 1
                 and "QUALIFY root complete." in visible(), name, 180)
    else:
        wait_for(lambda: len(receipts)>before and "QUALIFY "+phase+" complete." in visible(), name)
    drain(2)
    snap(name+"-complete")
    stop()
    return receipts[before:]
def cost(rows):
    return sum((Decimal(r["exact_usd"]) for r in rows), Decimal(0)).normalize()
def assert_metrics(text, rows):
    require(text, "Known subtotal exact USD: "+format(cost(rows), "f"), "exact independent total")
    for label, val in [
        ("Input", sum(r["input"] for r in rows)),
        ("Noncached input (derived for inclusive input)", sum(r["input"]-r["cached"] for r in rows)),
        ("Cache read", sum(r["cached"] for r in rows)),
        ("Cache write", 0),
        ("Output", sum(r["output"] for r in rows)),
        ("Reasoning (subset, not separately billed)", sum(r["reasoning"] for r in rows)),
        ("Total (not separately billed)", sum(r["input"]+r["output"] for r in rows)),
    ]:
        require(text, f"{label}: {val} known + unknown in 0 attempts", label)
def selected(name):
    return json.loads((out / (name+"-selected.json")).read_text())
def detail_members(name, rows):
    # Traverse every rendered request/attempt. Expected token/time/model tuples
    # come exclusively from server emissions and chosen clock inputs.
    found = []
    for request_label in [s for s in selected(name) if s.startswith("Request ") and s[8:].isdigit()]:
        open_link(request_label)
        req_name = name+"-"+request_label.replace(" ", "-")
        page(req_name)
        for attempt_label in [s for s in selected(req_name) if s.startswith("Attempt ") and s[8:].isdigit()]:
            open_link(attempt_label)
            detail_name = req_name+"-"+attempt_label.replace(" ", "-")
            text = page(detail_name)
            lines = selected(detail_name)
            def field(prefix):
                return next(s[len(prefix):] for s in lines if s.startswith(prefix))
            item = dict(attempt=field("Attempt: "), model=field("Model: "),
                        admitted_ms=int(field("Admission time: ").split()[0]),
                        input=int(field("Input: ")), exact_usd=field("Known subtotal exact USD: "))
            matches = [r for r in rows if r["model"]==item["model"] and r["input"]==item["input"]
                       and epoch(r["fixture_utc"])==item["admitted_ms"]]
            assert len(matches)==1, (name, item, matches)
            require(text, "Known subtotal exact USD: "+matches[0]["exact_usd"], detail_name)
            item["emission"] = matches[0]["emission"]
            found.append(item)
            send("\x1b")
        send("\x1b")
    assert sorted(r["emission"] for r in found)==sorted(r["emission"] for r in rows), (name, found, rows)
    assert len({r["attempt"] for r in found})==len(found), name
    return found
def bucket(group, start, end, windows, label):
    command(f"/usage requests {start} {end} {group}")
    page(label+"-overview")
    for index, (a,b) in enumerate(windows):
        link = f"{group.title()} [{a.replace('Z','.000Z')}, {b.replace('Z','.000Z')})"
        open_link(link)
        name = label+"-"+str(index)
        text = page(name)
        rows = [r for r in expected if r["kind"]!="orphan" and epoch(a)<=epoch(r["fixture_utc"])<epoch(b)]
        assert_metrics(text, rows)
        members = detail_members(name, rows)
        summary["buckets"].append(dict(page=name, group=group, start=a, end=b, exact_usd=str(cost(rows)),
                                       members=members, excluded_emissions=[
                                           r["emission"] for r in expected if r["kind"]!="orphan" and r not in rows]))
        send("\x1b")
    send("\x1b")
    save("results.json", summary)